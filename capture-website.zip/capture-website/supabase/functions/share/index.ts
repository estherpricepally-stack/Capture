// Serves one shared recording at a time, after checking who may watch it.
// Deploy:  supabase functions deploy share --no-verify-jwt
// (--no-verify-jwt lets people without an account open "anyone with the link" recordings;
//  for "only people I add", the function checks the signed-in person itself.)
import { createClient } from "jsr:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "not_found" }, 404);

  let id: unknown;
  try { ({ id } = await req.json()); } catch { return json({ error: "not_found" }, 404); }
  if (typeof id !== "string" || !/^[0-9a-z-]{8,64}$/i.test(id)) return json({ error: "not_found" }, 404);

  const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data: rec } = await admin.from("recordings")
    .select("id, owner, title, description, storage_path, mime, duration, trim_start, trim_end, markers, access, allowed, created_at")
    .eq("id", id).maybeSingle();
  if (!rec) return json({ error: "not_found" }, 404);

  // Who's asking? Signed-out visitors send the public key, which belongs to no one.
  let uid: string | null = null;
  const auth = req.headers.get("Authorization");
  if (auth?.startsWith("Bearer ")) uid = (await admin.auth.getUser(auth.slice(7))).data.user?.id ?? null;
  let isAdmin = false;
  if (uid) isAdmin = !!(await admin.from("profiles").select("is_admin").eq("id", uid).maybeSingle()).data?.is_admin;

  const isOwner = uid !== null && uid === rec.owner;
  if (rec.access === "people" && !isOwner && !isAdmin && !(uid && (rec.allowed as string[]).includes(uid))) {
    return json({ error: uid ? "no_access" : "sign_in_required" }, 403);
  }

  // A private link straight to the file that stops working after 4 hours.
  const { data: signed, error } = await admin.storage.from("recordings").createSignedUrl(rec.storage_path, 60 * 60 * 4);
  if (error || !signed) return json({ error: "file_missing" }, 404);

  const { data: owner } = await admin.from("profiles").select("display_name").eq("id", rec.owner).maybeSingle();
  const { allowed: _a, storage_path: _p, owner: _o, ...visible } = rec;
  return json({ ...visible, url: signed.signedUrl, owner_name: owner?.display_name || "Someone", is_owner: isOwner });
});
