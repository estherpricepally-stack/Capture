-- Capture: database setup. Run once in Supabase (SQL Editor, New query, paste, Run).
-- Safe to run again; it only adds what's missing.

-- ============ Profiles: one per account, created automatically on sign-up ============
create table if not exists public.profiles (
  id uuid primary key references auth.users on delete cascade,
  email text unique not null,
  display_name text,
  is_admin boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.profiles add column if not exists is_admin boolean not null default false;
alter table public.profiles enable row level security;

-- Is the person making this request an admin? Used by the rules below.
create or replace function public.is_admin() returns boolean
language sql security definer set search_path = public stable as $$
  select coalesce((select is_admin from public.profiles where id = auth.uid()), false);
$$;

drop policy if exists "read own profile" on public.profiles;
create policy "read own profile" on public.profiles for select to authenticated using (id = auth.uid() or public.is_admin());
drop policy if exists "update own profile" on public.profiles;
create policy "update own profile" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- Nobody can make themselves an admin from the app: only this SQL editor can change is_admin.
create or replace function public.protect_admin_flag() returns trigger
language plpgsql as $$
begin
  if new.is_admin is distinct from old.is_admin and current_user not in ('postgres', 'supabase_admin', 'service_role') then
    new.is_admin := old.is_admin;
  end if;
  return new;
end $$;
drop trigger if exists protect_admin_flag on public.profiles;
create trigger protect_admin_flag before update on public.profiles for each row execute function public.protect_admin_flag();

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, display_name)
  values (new.id, lower(new.email), coalesce(nullif(trim(new.raw_user_meta_data->>'display_name'), ''), split_part(new.email, '@', 1)))
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create or replace function public.handle_user_email_change() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update public.profiles set email = lower(new.email) where id = new.id;
  return new;
end $$;
drop trigger if exists on_auth_user_email_changed on auth.users;
create trigger on_auth_user_email_changed after update of email on auth.users for each row execute function public.handle_user_email_change();

-- ============ Shared recordings (the video file itself is in Storage) ============
create table if not exists public.recordings (
  id text primary key,
  owner uuid not null default auth.uid() references auth.users on delete cascade,
  title text not null default 'Untitled recording' check (char_length(title) <= 200),
  description text not null default '' check (char_length(description) <= 5000),
  storage_path text not null,
  mime text, size bigint, duration real,
  trim_start real not null default 0, trim_end real,
  markers jsonb not null default '[]'::jsonb,
  thumb text check (thumb is null or char_length(thumb) < 200000),
  access text not null default 'link' check (access in ('link', 'people')),
  allowed uuid[] not null default '{}',
  created_at timestamptz not null default now()
);
create index if not exists recordings_owner_idx on public.recordings (owner, created_at desc);
create index if not exists recordings_allowed_idx on public.recordings using gin (allowed);
alter table public.recordings enable row level security;

drop policy if exists "owner full access" on public.recordings;
create policy "owner full access" on public.recordings for all to authenticated
  using (owner = auth.uid()) with check (owner = auth.uid() and storage_path like auth.uid()::text || '/%');
drop policy if exists "added people can read" on public.recordings;
create policy "added people can read" on public.recordings for select to authenticated
  using (access = 'people' and auth.uid() = any(allowed));
drop policy if exists "admins can read all" on public.recordings;
create policy "admins can read all" on public.recordings for select to authenticated using (public.is_admin());
drop policy if exists "admins can remove" on public.recordings;
create policy "admins can remove" on public.recordings for delete to authenticated using (public.is_admin());
-- "Anyone with the link" recordings are not listable. They're served one at a time, by id, through the share function.

-- Exact-email lookup when sharing with someone, so nobody can browse who has an account.
create or replace function public.find_user_by_email(p_email text)
returns table (id uuid, display_name text, email text)
language sql security definer set search_path = public stable as $$
  select p.id, p.display_name, p.email from public.profiles p
  where auth.uid() is not null and p.email = lower(trim(p_email)) limit 1;
$$;
-- Names for people you share with, and for owners who shared with you. Nobody else.
create or replace function public.profiles_for(ids uuid[])
returns table (id uuid, display_name text, email text)
language sql security definer set search_path = public stable as $$
  select p.id, p.display_name, p.email from public.profiles p
  where auth.uid() is not null and p.id = any(ids) and (
    p.id = auth.uid() or public.is_admin()
    or exists (select 1 from public.recordings r where r.owner = auth.uid() and p.id = any(r.allowed))
    or exists (select 1 from public.recordings r where r.owner = p.id and r.access = 'people' and auth.uid() = any(r.allowed))
  );
$$;
revoke all on function public.find_user_by_email(text) from anon, public;
revoke all on function public.profiles_for(uuid[]) from anon, public;
grant execute on function public.find_user_by_email(text) to authenticated;
grant execute on function public.profiles_for(uuid[]) to authenticated;

-- ============ Each person's folders, view choice and Google Drive copies ============
create table if not exists public.libraries (
  user_id uuid primary key default auth.uid() references auth.users on delete cascade,
  state jsonb not null default '{}'::jsonb check (pg_column_size(state) < 262144),
  updated_at timestamptz not null default now()
);
alter table public.libraries enable row level security;
drop policy if exists "own library" on public.libraries;
create policy "own library" on public.libraries for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ============ Feedback: anyone can send it, only admins can read it ============
create table if not exists public.feedback (
  id bigserial primary key,
  user_id uuid references auth.users on delete set null,
  mood text, body text check (char_length(body) <= 5000), user_agent text,
  read boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.feedback add column if not exists read boolean not null default false;
alter table public.feedback enable row level security;
drop policy if exists "send own feedback" on public.feedback;
drop policy if exists "anyone can send feedback" on public.feedback;
create policy "anyone can send feedback" on public.feedback for insert to anon, authenticated
  with check ((user_id is null or user_id = auth.uid()) and read = false);
drop policy if exists "admins read feedback" on public.feedback;
create policy "admins read feedback" on public.feedback for select to authenticated using (public.is_admin());
drop policy if exists "admins update feedback" on public.feedback;
create policy "admins update feedback" on public.feedback for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admins delete feedback" on public.feedback;
create policy "admins delete feedback" on public.feedback for delete to authenticated using (public.is_admin());

-- ============ Video storage: a private bucket ============
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('recordings', 'recordings', false, 52428800, array['video/webm', 'video/mp4'])
on conflict (id) do update set public = false, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "owners upload videos" on storage.objects;
create policy "owners upload videos" on storage.objects for insert to authenticated
  with check (bucket_id = 'recordings' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "owners update videos" on storage.objects;
create policy "owners update videos" on storage.objects for update to authenticated
  using (bucket_id = 'recordings' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "owners read videos" on storage.objects;
create policy "owners read videos" on storage.objects for select to authenticated
  using (bucket_id = 'recordings' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));
drop policy if exists "owners delete videos" on storage.objects;
create policy "owners delete videos" on storage.objects for delete to authenticated
  using (bucket_id = 'recordings' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));

-- ============ Make yourself an admin ============
-- After you've created your account in Capture, run this with your email:
--   update public.profiles set is_admin = true where email = 'you@example.com';
