# Capture: screen recorder

People sign up with their **email and a password**. Accounts, shared recordings, folders and feedback are stored in
**Supabase**, which has a free plan.

| File | What it is |
|---|---|
| `index.html` | The homepage and the whole website: sign-in, studio, library, recording pages, account settings, help, feedback and the admin. |
| `admin.html` | A shortcut that opens the admin (`index.html#admin`). |
| `supabase/schema.sql` | The database: tables, and the rules for who can see and change what. |
| `supabase/functions/share/index.ts` | Serves share links, checking who's allowed to watch. |

Until it's connected, the site works in guest mode: people can record, draw and download, and the sign-in screen
says accounts aren't switched on yet.

## Setup (about 15 minutes)

**1. Create a Supabase project** at https://supabase.com (free).

**2. Create the database.** In Supabase, open **SQL Editor**, then **New query**. Paste all of `supabase/schema.sql` and press **Run**.
Use a new project: an older `capture-app` project has a different recordings table.

**3. Set up sign-in.** Go to **Authentication**, then **Sign In / Providers**, then **Email**:
- Turn on **Confirm email**, so nobody can sign up with someone else's address.
- Set the minimum password length to **8**.

Then go to **Authentication**, then **URL Configuration**. Set **Site URL** to your website's address, and add the same
address under **Redirect URLs**. The links in confirmation and password-reset emails send people there.

**4. Deploy the share function.** Install the Supabase CLI (https://supabase.com/docs/guides/cli), then in this folder run:
```
supabase login
supabase link --project-ref YOUR-PROJECT-REF
supabase functions deploy share --no-verify-jwt
```

**5. Connect the website.** In Supabase, go to **Project Settings**, then **API**. Copy the **Project URL** and the
**anon public** key into the top of the script in `index.html`:
```js
supabaseUrl: "https://abcdefgh.supabase.co",
supabaseAnonKey: "eyJhbGciOi...",
```
The anon key is meant to be public. The database rules from step 2 are what keep data safe.

**6. Put it online.** Upload the folder to any static host. The quickest is Netlify Drop (https://app.netlify.com/drop):
drag the folder in. Use the `https://` address it gives you, because browsers only allow screen recording on secure pages.
Then go back to step 3 and set that address as the Site URL.

**7. Make yourself an admin.** Create your account on the site, then run this in Supabase's SQL Editor with your email:
```sql
update public.profiles set is_admin = true where email = 'you@example.com';
```
Reload the site and **Admin** appears in the left rail. Nobody can make themselves an admin from the website itself.

**8. Before real users arrive: set up email sending.** Supabase's built-in email only sends a few messages an hour,
so confirmation and password-reset emails stop arriving. Go to **Authentication**, then **Emails**, then **SMTP Settings**,
and connect an email service such as Resend, Postmark or SendGrid (most have a free tier).

### Optional: Save to Google Drive
1. In Google Cloud Console (https://console.cloud.google.com), create a project and enable the **Google Drive API**.
2. Under **Google Auth Platform**, set up the consent screen and add the scope `.../auth/drive.file`. Publish it: this scope doesn't need Google's review.
3. Create an **OAuth client ID** of type **Web application**, and add your site's address under **Authorized JavaScript origins**.
4. Paste the client ID into `googleClientId` in `index.html`.

Capture can then create files in a "Capture recordings" folder, and can only see the files it created itself.

## Accounts and security

- **Passwords:** at least 8 characters, with letters and numbers. A strength meter guides people. Supabase stores only
  a salted hash of each password, and limits repeated guessing.
- **Email confirmation:** new accounts confirm their address before signing in, and can ask for the link again.
- **Forgot password:** sends a one-time reset link that expires after an hour. The message is the same whether or not
  an account exists, so the form can't be used to find out who has an account.
- **Changing your password** asks for the current one first, so someone at an unlocked computer can't lock you out.
- **Sign out everywhere** ends every session on every device.
- **Guest mode:** record without an account. Guest recordings move into an account created on the same device.
- **Shared computers:** each account only sees its own recordings on the device.

## Sharing
- **Anyone with the link** can watch in their browser, without an account.
- **Only people I add:** add people by their email. They need a Capture account, and are asked to sign in before watching.
- Shared videos are kept private in storage. Each viewing uses a temporary link that expires after 4 hours.
- Shared recordings can be up to 50 MB each. A free Supabase project includes 1 GB of storage in total.

## The admin
Only for admin accounts (step 7). Open it from **Admin** in the left rail, or go to `admin.html`.
- **Overview:** shared recordings, people sharing, storage used, and feedback with a mood breakdown.
- **Shared recordings:** everything anyone has shared, with who shared it and who can watch. Watch it, copy its link, or remove it.
- **Feedback:** **private to admins**, enforced by the database. Unread messages are highlighted and counted on the nav.
  Mark read or unread, delete, search, filter, and export a spreadsheet (CSV).

## Tested
- 39 end-to-end checks against a simulated Supabase, covering: the not-connected state, sign-up, weak passwords,
  wrong password, forgot password, email confirmation and resend, changing your password, sign out, folders saving to the account,
  upload and share links, sharing by email, opening links signed out, private feedback, admin access and moderation,
  guest recordings moving into an account, two accounts on one computer, and phones.
- Real recording with a simulated screen saves to the signed-in account.
- Recordings from the earlier claude.ai version go to the first account that signs in on that device.
